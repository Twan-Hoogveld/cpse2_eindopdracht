Het project is gebuild op Ubuntu 20.04 met een zelf gecompileerde SFML library & gelinked met Cmake (Sorry Wouter, ik weet dat je CMake haat.)

Het bestand in build, genaamd SFMLApp is dan ook te runnen op ubuntu en werkt naar behoren.
1 bug is bekend met de foreground knop, background werkt wel. Kan misschien zijn dat de fonts niet inladen want die zijn met een ubuntu path aangegeven. Dus graag runnen op ubuntu. Op het path aanpassen en je eigen font toevoegen.

bij vragen hoor ik het graag.