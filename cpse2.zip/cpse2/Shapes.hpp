#ifndef SHAPES_HPP
#define SHAPES_HPP

#include "Shapes/Circle.hpp"
#include "Shapes/MoveableObject.hpp"
#include "Shapes/Rectangle.hpp"
#include "Shapes/Dummy.hpp"
#endif  // SHAPES_HPP